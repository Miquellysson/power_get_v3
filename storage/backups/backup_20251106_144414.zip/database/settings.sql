CREATE TABLE `settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `skey` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `svalue` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_settings_skey` (`skey`)
) ENGINE=InnoDB AUTO_INCREMENT=341 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
